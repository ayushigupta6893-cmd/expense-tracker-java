
 <%@  taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
 
 <%@page isELIgnored="false" %>

<nav class="navbar navbar-expand-lg navbar-light bg-success">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Expense Tracker</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      <c:if test="${ empty loginUser }">
        <li class="nav-item">
          <a class="nav-link active" href="register.jsp"><i class="fa-regular fa-id-card"></i>Register</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="login.jsp"><i class="fa-solid fa-arrow-right-to-bracket"></i>Login</a>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.jsp"><i class="fa-solid fa-house"></i>Home</a>
        </li>
        </c:if>
     
       
         <c:if test="${not empty loginUser }">
         
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../index.jsp">Home</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link active" href="add_expense.jsp"><i class="fa-solid fa-plus"></i>Add expense</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="view_expense.jsp"><i class="fa-solid fa-align-center"></i>view expense </a>
        </li>
       </c:if>
      
      
        
        
         <c:if test="${not empty loginUser }">
        <li class="nav-item">
          <a class="nav-link active" href="#"><i class="fa-regular fa-id-card"></i>${loginUser.name }</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="../logout"><i class="fa-solid fa-arrow-right-to-bracket"></i>logout</a>
        </li>
        
        
        
        
        
        </c:if>
        
        
          
        
      </ul>
      
    </div>
  </div>
</nav>